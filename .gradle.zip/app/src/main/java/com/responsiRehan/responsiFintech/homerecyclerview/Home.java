package com.responsiRehan.responsiFintech.homerecyclerview;

public class Home {

        private int img;
        private String title;
        private String pengarang;

        public Home() {
        }

        public int getImg() {
            return img;
        }

        public void setImg(int img) {
            this.img = img;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getPengarang() {
        return pengarang;
    }

        public void setPengarang(String title) {
        this.pengarang = title;
    }
}
