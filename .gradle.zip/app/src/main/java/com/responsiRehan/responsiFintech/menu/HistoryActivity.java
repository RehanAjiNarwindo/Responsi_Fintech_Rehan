package com.responsiRehan.responsiFintech.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.responsiRehan.responsiFintech.R;


public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_history);
    }
}